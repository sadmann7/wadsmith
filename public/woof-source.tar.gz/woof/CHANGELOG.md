## New Features and Improvements

* **Music:**
  - Add support for CLAP plugins. Recommended plugin for perfect Roland SC-55 emulation: [Nuked-SC55-CLAP](https://github.com/johnnovak/Nuked-SC55-CLAP).
  - Native MIDI features now work with all music backends:
    - Full EMIDI support.
    - RPG Maker and Final Fantasy loop points.
    - Reset type, capital tone emulation, MIDI complevel and others are available for CLAP plugins. Documentation: [wiki](https://github.com/fabiangreffrath/woof/wiki/MIDI).

* **Mod Support:**
  - Add support for optional menu and intermission sounds.
  - Add support for ambient sound definitions by SNDINFO lumps.
  - Color translation tables from PWADs are extended but never overridden.
  - Leave some more space in the HUD menu for the layout description.
  - Add support for optional chaingun sound, via `DSCHGUN`.
  - Improved support for using PK3 files via `-file`, better matching ZDoom PK3.
    The `autoload/` directory can now be used within PK3 files -- with the exception of `all-all/`, as it is not needed.
    Improved support for ZDoom-style `filter/` IWAD folders -- added `filter/game-doom/` and `filter/game-chex/`.
    Maps can now be loaded from WAD files within the `maps/` subdirectory.
    The `filter/` subdirectories are loaded first, before `autoload/` subdirectories.
    The subdirectories `colormaps/`, `flats/`, `sprites/`, `textures/`, `voxels/`, will map to their own `_START`/`_END` lump markers.
    The subdirectories `graphics/`, `maps/`, `music/`, `patches/`, `sounds/`, will map to the global lump list.
  - Add support for `comp_thingsectorlight`, in preparation for revision 1.5 of the MBF21 spec.

* **Quality of Life:**
  - Player view no longer abruptly jolts when running across very shallow floor height changes
  - The Minimap now always follows the player
  - The Automap player arrow has been widened for better visibility
  - Skip rest of line in DEHACKED lumps for Text section with too short length parameters
  - The Load/Save Game menus are now organized in tabs, instead of pages.
    The left-most tab of the Load Game menu is for Quick Saves, its first slot is reserved for Auto Save.
    Quick Saves are now immediate and always override the oldest available slot.
  - Added the "Move Over/Under Monsters" option (Off / Player only / All) to the Compatibility menu.
    The player, and optionally all monsters, can now pass over or under other solid, shootable things instead of colliding with them at any height.
    Things standing on other things are carried along by moving sectors.
    Monsters cannot hit things above or below them in melee if their heights do not overlap.
    The option is disabled in demos, netgames and strict mode.
  - Added a "Jump" key binding (unbound by default) with ZDoom-style jumping.
    Holding the key repeats the jump with a short delay after landing, and there is a little air control during a jump.
    Jumping also works on top of other things with the "Move Over/Under Monsters" option.
    It is disabled in demos, netgames and strict mode.
  - Add "Native MIDI Reset Type" to General->Audio->Music menu.
  - Add support for the `-chain_episodes` command line parameter from DSDA-Doom.
  - Add Sunlust MAP24 `comp_ledgeblock` fix to compatibility database

* **Rendering:**
  - Adapt multithread renderer from Rum and Raisin Doom. Effective at high resolutions, expect 2-4 times performance increase on multicore CPU.
  - Implemented support for square pixels: the Resolution Scale slider now has an additional "Native" setting
    which renders the game at the final vertical resolution instead of stretching the image artificially,
    improving image quality.
  - Implemented support for aspect ratios below 4:3, available through the "Auto" option of the Aspect Ratio setting.
  - Improved accuracy of plane rendering.
  - Improved palettization of PNG graphics, and general color approximation in the engine.
  - Implemented transposed rendering for improved rendering performance in general.
  - Optimized rendering of sprites near the camera.
  - Improved culling of sprites above and below the view (thanks to @JNechaevsky and @pvictress).
  - Added "Cylindrical" sky projection as a third option besides "Vanilla" and "Linear" (from Nugget Doom).

* **Multiplayer:**
  - Implemented rollback netcode: Processes local inputs instantly and predicts opponent actions, automatically rewinding and correcting the game state if a prediction is incorrect.
  - Added IPv6 support.

* **Input:**
  - Added community database of SDL controller mappings (gamecontrollerdb.txt).

## Bug Fixes

* Fixed setup desktop action exiting immediately when run from the AppImage
* Do not restart MUSINFO level music when restoring a savegame.
* Fixed autoloading of the DEHACKED lump that fixed colored blood for HACX
* The status bar border is now draw for all non-fullscreen HUDs
* [Linux] Fixed "Woof Setup" icon erroneously displaying on main "Woof" executable.
* Quicksave does not change the active Load Game / Save Game menu page anymore
* Fixed level title missing from the automap when the automap was not in overlay mode.
  * This affected only SBARDEF 1.0.0 HUDs, such as the ones included with D+D2 (id24res.wad/extras.wad)
* Fixed minimap overlapping chat in Legacy of Rust
* Fixed minimap key binding block cheat codes and chat messages
* Fixed demo desync by menu-pausing during the intermission screen
* Fixed DEHACKED-related crashes caused by calling player sprite actions as thinker functions (e.g. Blues Brothers 2023)
* Fixed mouse hit boxes for savegame entries in the Load Game / Save Game menus
* Fixed some occurances of undefined behavior in the code that led to demo desyncs caused by compiler optimizations
* Fixed SDL3 MacOSX compile directive. (CMD+Enter for fullscreen, Linux Steam folder search, 'Woof! Setup' help URL)
* Custom skill options no longer stay active on standard skills.
* The `Enemies` > `Helper Dogs` menu option now works again.
* Fixed data corruption when using WINUM font in SBARDEF.

## Miscellaneous

* Rearranged default HUD layouts: "Nightdive" and "Crispy" layouts swapped places
* Renamed MacOS build from "`Woof-<version>-uni.zip`" to "`Woof-<version>-MacOS-universal.zip`"
* Savegame description and snapshot are now saved outside the compressed keyframe to speed up populating the Load/Save Game menu pages
* The release artifacts now run on Windows 7 agains

## Regressions
* Deprecate and remove brightmaps support during the multithreaded renderer implementation.
