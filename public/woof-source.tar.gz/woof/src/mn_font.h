//
// SLADE - It's a Doom Editor
// Copyright(C) 2008 - 2019 Simon Judd
// Copyright(C) 2024 Roman Fomin
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
// DESCRIPTION:
//     Load and draw ZDoom FON2 fonts

#ifndef MN_FONT
#define MN_FONT

#include "doomtype.h"

boolean MN_LoadFon2(const byte *gfx_data, int size);

boolean MN_DrawFon2String(int x, int y, byte *cr, const char *str);

int MN_GetFon2PixelWidth(const char *str);

void MN_DrawStringCR(int cx, int cy, byte *cr1, byte *cr2, const char *ch);

void MN_DrawString(int cx, int cy, int color, const char *ch);

int MN_StringHeight(const char *ch);

int MN_StringWidth(const char *ch);

int MN_GetPixelWidth(const char *ch);

void MN_SetHUFontKerning(void);

#endif
