//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//     Networking module which uses SDL_net
//

#ifndef NW_SDL_H
#define NW_SDL_H

#include "nw_defs.h"

extern nw_module_t nw_sdl_module;

// Module used for server queries only: it has a socket of its own, so that
// searching for servers does not interfere with a game in progress.
extern nw_module_t nw_sdl_query_module;

// Close the UDP socket, so that the module can be initialized again.
void NW_ResetSocket(void);

#endif /* #ifndef NW_SDL_H */
