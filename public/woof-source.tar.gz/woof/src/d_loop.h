//
// Copyright(C) 1993-1996 Id Software, Inc.
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//	Main loop stuff.
//

#ifndef __D_LOOP__
#define __D_LOOP__

#include "doomtype.h"
#include "m_fixed.h"
#include "nw_defs.h"

// Callback function invoked while waiting for the netgame to start.
// The callback is invoked when new players are ready. The callback
// should return true, or return false to abort startup.

typedef boolean (*netgame_startup_callback_t)(int ready_players,
                                              int num_players);

// Create any new ticcmds and broadcast to other players.
void NetUpdate(void);

// Broadcasts special packets to other players
//  to notify of game exit
void D_QuitNetGame(void);

//? how many ticks to run?
void TryRunTics(void);

// Called at start of game loop to initialize timers
void D_StartGameLoop(void);

// Reset gametic/maketic, so that a network game can be started in the
// middle of a session.
void D_ResetTicState(void);

// Run the first tic of a freshly started game, so that the level can be
// rendered. Waits for the server tic when running a network game.
void D_RunFirstTic(void);

// Initialize networking code and connect to server.

boolean D_InitNetGame(nw_connect_data_t *connect_data);

// Same, but with explicit parameters. A NULL connect_addr means that the
// address is taken from the command line. When fatal is false, failures are
// reported and false is returned instead of exiting.

boolean D_InitNetGameParams(boolean server, const char *connect_addr,
                            boolean fatal, nw_connect_data_t *connect_data);

// Start game with specified settings. The structure will be updated
// with the actual settings for the game.

void D_StartNetGame(nw_gamesettings_t *settings,
                    netgame_startup_callback_t callback);

void D_ReceiveTic(ticcmd_t *ticcmds, boolean *players_mask);

extern fixed_t offsetms;

#endif
