Source for the Doom engine that Wadsmith runs in the browser.

woof/ is Woof 16.0.0, commit f28403885a48cfd90cfb9e1f92aaabb16361df8a, from
https://github.com/fabiangreffrath/woof. Woof is under the GNU GPL, version 2, in woof/COPYING.

wadsmith/woof.patch is every change Wadsmith makes to it. Apply it from
inside woof/ with: patch -p1 < ../wadsmith/woof.patch

wadsmith/setup-engine.mjs builds woof.js and woof.wasm with Emscripten
7.0.0 and lists every source file and compiler flag. It expects
Wadsmith's repository layout, with the patch in engine/woof.patch.
